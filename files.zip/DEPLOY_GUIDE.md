# Making the IPE "Team Meeting" simulator live — step by step

This turns the simulator into a real web page (a link) your students open on any device — no login, no Claude account needed. It takes about 30–45 minutes the first time. **If you're not comfortable with the technical steps, hand this whole folder and this guide to Gannon IT or a TA — it's a small, standard task for them.**

**What's in this folder**
- `index.html` — the simulator (the part students see)
- `api/chat.js` — a tiny backend that keeps your API key secret
- `DEPLOY_GUIDE.md` — this guide

---

## Step 1 — Get an Anthropic API key (≈10 min)
This is separate from your $20/month Claude subscription. It's pay-as-you-go.

1. Go to **console.anthropic.com** and sign up (or log in).
2. Add a payment method under **Billing**.
3. **Set a monthly spending limit** (Billing → Limits). Set something small like **$20** so it can never surprise you. *(Do not skip this.)*
4. Go to **API Keys → Create Key**. Copy the key (starts with `sk-ant-…`) and paste it somewhere safe for a minute. **Treat it like a password — never put it in an email, a slide, or the webpage.**

## Step 2 — Put the code on GitHub (≈10 min)
The host reads your code from GitHub.

1. Make a free account at **github.com**.
2. Click **New repository** → name it `ipe-huddle` → **Create**.
3. On the repo page, click **Add file → Upload files**, and drag in **`index.html`** and the **`api`** folder (with `chat.js` inside). Commit.

## Step 3 — Deploy on Vercel (≈10 min)
Vercel hosts the page and runs the backend. Free tier is plenty for a class.

1. Go to **vercel.com** and **Sign up with GitHub**.
2. Click **Add New → Project**, pick your `ipe-huddle` repo, click **Import**.
3. **Before you click Deploy**, open **Environment Variables** and add one:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** paste your `sk-ant-…` key
4. Click **Deploy**. In a minute you'll get a link like `https://ipe-huddle.vercel.app`.

## Step 4 — Test it
Open the link on your computer **and** on your phone/iPad. Start a patient, send a message, confirm the team responds and the download button works. If it responds, you're done — that link is what you give students.

---

## Costs — what to expect
- Each student run is roughly **10–20 short messages** ≈ **a few cents**.
- A class of 24 doing it once or twice is likely **$1–$3 total**.
- Your Step 1 spending cap is your safety net.

## Sharing with students
Just give them the link. It works on any device, no account. (Optional: keep the link a little private — post it in Blackboard rather than on the open web — so only your students use it.)

## If something breaks
- **"Team connection dropped" every time:** the API key env var is missing or misspelled in Vercel (must be exactly `ANTHROPIC_API_KEY`). Fix it under Vercel → Settings → Environment Variables, then **Redeploy**.
- **Nothing loads:** make sure `index.html` is at the top level of the repo and `chat.js` is inside an `api` folder.
- **Bill worry:** check Anthropic console → Usage; your spending limit caps it regardless.

## Handing it off
If Gannon IT or a TA does this, they need: this folder, and you'll create the Anthropic key (Step 1) and give it to them privately for Step 3's environment variable — or let them create it under a department account.
